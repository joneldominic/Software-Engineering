/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package team.tokhang.cs138;

/**
 *
 * @author USER
 */
import java.sql.*;
public class connection {
    private static Connection conn = null;
    
    private static String username;
    private static String password;
    private static String database;
    
    public static Connection ConnectDB(String username, String password, String hostName, String databaseName){
        try{
            connection.username = username;
            connection.password = password;
            database = "jdbc:mysql://" + hostName + "/" + databaseName;
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(database,username,password);
            return conn;
        }catch (Exception e){
            System.out.println("Error " + e);
            return null; 
        }
    }   
}
