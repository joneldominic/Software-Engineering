/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package team.tokhang.cs138;

import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Team Tokhang
 */
public class SubjectUpdate extends javax.swing.JFrame {

    private Connection myCon;
    private String username;
    private String password;
    private String hostName;
    private String databaseName;
    private int mysID;
    private ArrayList<Integer> subjectID;
    private ArrayList<Integer> classTypeID;
    private ArrayList<Integer> preSubjCBID;
    private ArrayList<Integer> preSubjID;
    boolean visible = true;
    /**
     * Creates new form SubjectUpdate
     */
    public SubjectUpdate() {
        initComponents();
        setLocationRelativeTo(this);
        setResizable(false);
        
        btnAddPre.setEnabled(false);
        btnDelPre.setEnabled(false);
        btnDelCType.setEnabled(false);
        btnAddClassType.setEnabled(false);
        panelContainer.setVisible(false);
        setServerInformation("root", "", "localhost", "villabacampus_db");
        setServer();
        
        fillSubjectTable("");
        fillPrqstSubjCB();
    }
    
    private void setIcon() {
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("../Images/vsu.jpg")));
    }
    
     public void setServerInformation(String username, String password, String hostName, String databaseName){
        
        this.username = username;
        this.password = password;
        this.hostName = hostName;
        this.databaseName = databaseName;
        
    }
    
    public void setServer(){
        myCon = connection.ConnectDB(username, password, hostName, databaseName);
    }
    
    public void fillSubjectTable(String searchSubjectTitle){
        subjectID = new ArrayList<>();
        
        String query = "SELECT subjectID, subjectCode, subjectTitle FROM subjects WHERE subjectTitle LIKE ? ORDER BY subjectCode ASC";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(query);
            myStat.setString(1, "%" + searchSubjectTitle + "%");
            ResultSet rs = myStat.executeQuery();
            
            DefaultTableModel model = (DefaultTableModel) jTable_Subject.getModel();
            model.setRowCount(0);
            
            while(rs.next())
            { 
                subjectID.add(rs.getInt("subjectID"));
                String subjectCode = rs.getString("subjectCode");
                String subjectTitle = rs.getString("subjectTitle");
                
                model.insertRow(jTable_Subject.getRowCount(), new Object[] {subjectCode, subjectTitle});
            }
            
        } catch (Exception e){
            System.out.println("Error : " + e);
        }

    }
    
    public void fillPrqstSubjCB() {
        preSubjCBID = new ArrayList<>();
        cbSubjects.removeAllItems();
        
        String query = "SELECT subjectID, subjectCode FROM subjects ORDER BY subjectCode ASC";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(query);
            ResultSet rs = myStat.executeQuery();
            
            while(rs.next())
            { 
                preSubjCBID.add(rs.getInt("subjectID"));
                cbSubjects.addItem(rs.getString("subjectCode"));
            }
            
        } catch (Exception e){
            System.out.println("Error : " + e);
        }
    }
    
    public void fillPreSubjList(int sID) {
        preSubjID = new ArrayList<>();
        
        String query = "SELECT s.subjectID, s.subjectCode, s.subjectTitle from subjects s inner join prerequisite p where s.subjectID=p.preSubjectID and p.subjectID = ?";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(query);
            myStat.setInt(1, sID);
            ResultSet rs = myStat.executeQuery();
            
            DefaultTableModel model = (DefaultTableModel) jTable_PreSubj.getModel();
            model.setRowCount(0);
            
            while(rs.next())
            { 
                preSubjID.add(rs.getInt("subjectID"));
                String subjectCode = rs.getString("subjectCode");
                String subjectTitle = rs.getString("subjectTitle");
                
                model.insertRow(jTable_PreSubj.getRowCount(), new Object[] {subjectCode, subjectTitle});
            }
            
        } catch (Exception e){
            System.out.println("Error : " + e);
        }
    }
    
    public void fillClassTypeTable(int subjectID){
        classTypeID = new ArrayList<>();
        
        String query = "SELECT subjectID, subjectType, hours FROM subjectdetails WHERE subjectID = ? ORDER BY subjectType ASC";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(query);
            myStat.setInt(1, subjectID);
            ResultSet rs = myStat.executeQuery();
            
            DefaultTableModel model = (DefaultTableModel) jTable_ClassType.getModel();
            model.setRowCount(0);
            
            while(rs.next())
            { 
                classTypeID.add(rs.getInt("subjectID"));
                String subjectType = rs.getString("subjectType");
                int hours = rs.getInt("hours");
                
                model.insertRow(jTable_ClassType.getRowCount(), new Object[] {subjectType, hours});
            }
            
            //Center Alignment for hour(column)
            DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
            centerRenderer.setHorizontalAlignment(javax.swing.JLabel.CENTER);
            jTable_ClassType.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);
            
        } catch (Exception e){
            System.out.println("Error : " + e);
        }

    }
    
    public void getSelectedSubject(int sID){
         
        String query = "SELECT subjectID, subjectCode, subjectTitle, units FROM subjects WHERE subjectID = ?";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(query);
            myStat.setInt(1, sID);
            ResultSet rs = myStat.executeQuery();

            if(rs.next())
            { 
                jTextField_SubjectCode.setText(rs.getString("subjectCode"));
                jTextField_SubjectTitle.setText(rs.getString("subjectTitle"));
                jTextField_Units.setText(String.valueOf(rs.getInt("units")));
            }

        } catch (Exception e){
            System.out.println("Error : " + e);
        }
    }
    
    public void getSelectedSubjectInfo(){
        int i;
        if(jTable_Subject.getSelectedRowCount() == 1){
            i = jTable_Subject.getSelectedRow();
            getSelectedSubject(subjectID.get(i));
            fillClassTypeTable(subjectID.get(i));
            fillPreSubjList(subjectID.get(i));
            mysID = subjectID.get(i);
        }
        else if (jTable_Subject.getSelectedRowCount() == 0) {
            i = 0;
            getSelectedSubject(subjectID.get(i));
            fillClassTypeTable(subjectID.get(i));
            fillPreSubjList(subjectID.get(i));
            mysID = subjectID.get(i);
        }
        
    }
    
    public void addSubject()
    {
        String qry = "Insert into subjects (subjectCode, subjectTitle, units) VALUES (\" \", \"edit me\", 3)";
        
        try
        {
            PreparedStatement stmt = myCon.prepareStatement(qry);
            stmt.executeUpdate();
   
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
    
    public void saveSubject(int sID)
    {
        String qry = "Update subjects SET subjectCode = ?, subjectTitle = ?, units = ? WHERE subjectID = ?";
        
        try
        {
            PreparedStatement stmt = myCon.prepareStatement(qry);
            stmt.setString(1, jTextField_SubjectCode.getText());
            stmt.setString(2, jTextField_SubjectTitle.getText());
            stmt.setInt(3, Integer.valueOf(jTextField_Units.getText()));
            stmt.setInt(4, sID);
            stmt.executeUpdate();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
    
    public void deleteSubject(int sID)
    {
       String qry = "Delete s.*, sd.* from subjects s left join subjectdetails sd on s.subjectID = sd.subjectID Where s.subjectID = ?";
       
       try
       {
           PreparedStatement stmt = myCon.prepareStatement(qry);
           stmt.setInt(1, sID);
           stmt.executeUpdate();
           
       }
       catch(Exception e)
       {
           JOptionPane.showMessageDialog (null, "Failed to Delete Subject", "Error", JOptionPane.ERROR_MESSAGE);
           System.out.println(e);
       }
    }
    public void ClassType(int sID)
    {
        String qry = "INSERT INTO subjectdetails (subjectType, hours, subjectID) VALUES (?, ?, ?)";
        
        try
        {
            PreparedStatement stmt = myCon.prepareStatement(qry);
            stmt.setString(1, (String) cbClassType.getSelectedItem());
            stmt.setString(2, txtHours.getText());
            stmt.setInt(3, sID);
            stmt.executeUpdate();
        }
        catch(SQLException e)
        {
            qry = "Update subjectdetails SET hours = ? where subjectID = ? and subjectType = ?";

            try
            {
                PreparedStatement stmt = myCon.prepareStatement(qry);        
                stmt.setString(1, txtHours.getText());
                stmt.setInt(2, sID);
                stmt.setString(3, cbClassType.getSelectedItem().toString());
                stmt.executeUpdate();
            }
            catch(Exception ex)
            {
                System.out.println(ex);
            }
        }
    }
    
    public void addPrerequisite() {
        String qry = "INSERT INTO prerequisite (subjectID, preSubjectID) VALUES (?,?)";
        
        try
        {
            PreparedStatement stmt = myCon.prepareStatement(qry);
            stmt.setInt(1, subjectID.get(jTable_Subject.getSelectedRow()));
            stmt.setInt(2, preSubjCBID.get(cbSubjects.getSelectedIndex()));
            stmt.executeUpdate();
        }
        catch(SQLException e)
        {
            System.out.println("Error: "+e);
        }
    }
    
    public void getSelectedClassType(int sID, String sType){
        String query = "SELECT `subjectType`, `hours` FROM `subjectdetails` WHERE subjectID = ? and subjectType = ?";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(query);
            myStat.setInt(1, sID);
            myStat.setString(2, sType);
            ResultSet rs = myStat.executeQuery();

            if(rs.next())
            { 
                cbClassType.setSelectedItem(rs.getString("subjectType"));
                txtHours.setText(String.valueOf(rs.getInt("hours")));
            }

        } catch (Exception e){
            System.out.println("Error : " + e);
        }
    }
    
    public void delPrerequisite(){
        String qry = "Delete from prerequisite where subjectID = ? and preSubjectID = ?";
       
       try
       {
           PreparedStatement stmt = myCon.prepareStatement(qry);
           stmt.setInt(1, subjectID.get(jTable_Subject.getSelectedRow()));
           stmt.setInt(2, preSubjID.get(jTable_PreSubj.getSelectedRow()));
           stmt.executeUpdate();
           
       }
       catch(Exception e)
       {
           JOptionPane.showMessageDialog (null, "Failed to Delete Prerequisite", "Error", JOptionPane.ERROR_MESSAGE);
           System.out.println(e);
       }
       fillPreSubjList(mysID);
    }
    
    public void delClassType(int sID, String type) {
        String qry = "Delete from subjectdetails where subjectID = ? and subjectType = ?";
       
       try
       {
           PreparedStatement stmt = myCon.prepareStatement(qry);
           stmt.setInt(1, sID);
           stmt.setString(2, type);
           stmt.executeUpdate();
           
       }
       catch(Exception e)
       {
           JOptionPane.showMessageDialog (null, "Failed to Delete Class Type", "Error", JOptionPane.ERROR_MESSAGE);
           System.out.println(e);
       }
       fillClassTypeTable(sID);
    }
    
    public void fillPanel()
    {
        if(jTable_ClassType.getSelectedRowCount() == 1){
            int i = jTable_Subject.getSelectedRow();
            getSelectedClassType(subjectID.get(i), (String) jTable_ClassType.getValueAt(jTable_ClassType.getSelectedRow(), 0));
        }   
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_Subject = new javax.swing.JTable();
        jTextField_SearchTitle = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTextField_SubjectCode = new javax.swing.JTextField();
        jTextField_SubjectTitle = new javax.swing.JTextField();
        jTextField_Units = new javax.swing.JTextField();
        btnAddSubj = new javax.swing.JButton();
        btnSaveSubj = new javax.swing.JButton();
        btnDelSubj = new javax.swing.JButton();
        pnlCType = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable_ClassType = new javax.swing.JTable();
        btnDelCType = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        btnAddPre = new javax.swing.JButton();
        btnDelPre = new javax.swing.JButton();
        cbSubjects = new javax.swing.JComboBox<>();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable_PreSubj = new javax.swing.JTable();
        panelContainer = new javax.swing.JPanel();
        lblType = new javax.swing.JLabel();
        cbClassType = new javax.swing.JComboBox<>();
        lblHours = new javax.swing.JLabel();
        txtHours = new javax.swing.JTextField();
        btnAdd = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        btnAddClassType = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Subject Update");

        jPanel1.setBackground(java.awt.Color.WHITE);

        jTable_Subject.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Subject Code", "Subject Title"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable_Subject.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_SubjectMouseClicked(evt);
            }
        });
        jTable_Subject.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTable_SubjectKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jTable_Subject);
        if (jTable_Subject.getColumnModel().getColumnCount() > 0) {
            jTable_Subject.getColumnModel().getColumn(0).setResizable(false);
            jTable_Subject.getColumnModel().getColumn(0).setPreferredWidth(150);
            jTable_Subject.getColumnModel().getColumn(1).setResizable(false);
            jTable_Subject.getColumnModel().getColumn(1).setPreferredWidth(500);
        }

        jTextField_SearchTitle.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextField_SearchTitleFocusGained(evt);
            }
        });
        jTextField_SearchTitle.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTextField_SearchTitleMouseClicked(evt);
            }
        });
        jTextField_SearchTitle.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField_SearchTitleKeyReleased(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        jLabel1.setText("Search Subject Title");

        jPanel2.setBackground(java.awt.Color.WHITE);
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jLabel2.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        jLabel2.setText("Subject Code");

        jLabel3.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        jLabel3.setText("Subject Title");

        jLabel4.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        jLabel4.setText("No. of Units");

        jTextField_SubjectCode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_SubjectCodeActionPerformed(evt);
            }
        });

        jTextField_SubjectTitle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_SubjectTitleActionPerformed(evt);
            }
        });

        jTextField_Units.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        btnAddSubj.setText("Add Subject");
        btnAddSubj.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddSubjActionPerformed(evt);
            }
        });

        btnSaveSubj.setText("Save");
        btnSaveSubj.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveSubjActionPerformed(evt);
            }
        });

        btnDelSubj.setText("Delete");
        btnDelSubj.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDelSubjActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 85, Short.MAX_VALUE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(6, 6, 6)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField_Units, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField_SubjectTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 328, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField_SubjectCode, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(btnAddSubj, javax.swing.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(btnSaveSubj, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnDelSubj, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextField_SubjectCode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jTextField_SubjectTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jTextField_Units, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAddSubj)
                    .addComponent(btnSaveSubj, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnDelSubj, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        pnlCType.setBackground(java.awt.Color.WHITE);
        pnlCType.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Century Gothic", 1, 12))); // NOI18N

        jTable_ClassType.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Class Type", "Hours"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable_ClassType.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_ClassTypeMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable_ClassType);
        if (jTable_ClassType.getColumnModel().getColumnCount() > 0) {
            jTable_ClassType.getColumnModel().getColumn(0).setResizable(false);
            jTable_ClassType.getColumnModel().getColumn(0).setPreferredWidth(300);
            jTable_ClassType.getColumnModel().getColumn(1).setResizable(false);
            jTable_ClassType.getColumnModel().getColumn(1).setPreferredWidth(100);
        }

        btnDelCType.setText("Delete Class Type");
        btnDelCType.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDelCTypeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlCTypeLayout = new javax.swing.GroupLayout(pnlCType);
        pnlCType.setLayout(pnlCTypeLayout);
        pnlCTypeLayout.setHorizontalGroup(
            pnlCTypeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlCTypeLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnDelCType)
                .addGap(54, 54, 54))
            .addGroup(pnlCTypeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );
        pnlCTypeLayout.setVerticalGroup(
            pnlCTypeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCTypeLayout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnDelCType)
                .addContainerGap())
        );

        jPanel5.setBackground(java.awt.Color.WHITE);
        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Prerequisites", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Century Gothic", 1, 12))); // NOI18N

        btnAddPre.setText("Add Prequisite");
        btnAddPre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddPreActionPerformed(evt);
            }
        });

        btnDelPre.setText("Delete Prequisite");
        btnDelPre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDelPreActionPerformed(evt);
            }
        });

        jTable_PreSubj.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Subject Code", "Subject Title"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable_PreSubj.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_PreSubjMouseClicked(evt);
            }
        });
        jTable_PreSubj.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTable_PreSubjKeyReleased(evt);
            }
        });
        jScrollPane4.setViewportView(jTable_PreSubj);
        if (jTable_PreSubj.getColumnModel().getColumnCount() > 0) {
            jTable_PreSubj.getColumnModel().getColumn(0).setResizable(false);
            jTable_PreSubj.getColumnModel().getColumn(0).setPreferredWidth(150);
            jTable_PreSubj.getColumnModel().getColumn(1).setResizable(false);
            jTable_PreSubj.getColumnModel().getColumn(1).setPreferredWidth(500);
        }

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 420, Short.MAX_VALUE)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(btnDelPre)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cbSubjects, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnAddPre)))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnDelPre)
                    .addComponent(btnAddPre)
                    .addComponent(cbSubjects, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(8, Short.MAX_VALUE))
        );

        panelContainer.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lblType.setText("Class Type: ");

        cbClassType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Laboratory", "Lecture" }));
        cbClassType.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbClassTypeActionPerformed(evt);
            }
        });

        lblHours.setText("No. of hours: ");

        btnAdd.setText("Save");
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });

        btnCancel.setText("Cancel");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelContainerLayout = new javax.swing.GroupLayout(panelContainer);
        panelContainer.setLayout(panelContainerLayout);
        panelContainerLayout.setHorizontalGroup(
            panelContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelContainerLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelContainerLayout.createSequentialGroup()
                        .addComponent(lblType)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cbClassType, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelContainerLayout.createSequentialGroup()
                        .addGroup(panelContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblHours)
                            .addGroup(panelContainerLayout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(btnAdd)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtHours, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnCancel)))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        panelContainerLayout.setVerticalGroup(
            panelContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelContainerLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(panelContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblType)
                    .addComponent(cbClassType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtHours, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(panelContainerLayout.createSequentialGroup()
                        .addComponent(lblHours)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnAdd)
                            .addComponent(btnCancel))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnAddClassType.setText("Add Class Type");
        btnAddClassType.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddClassTypeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField_SearchTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(pnlCType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(panelContainer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(btnAddClassType, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(48, 48, 48))))
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(15, 15, 15))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(pnlCType, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(26, 26, 26))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(panelContainer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnAddClassType)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addComponent(jLabel1))
                            .addComponent(jTextField_SearchTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1)))
                .addGap(16, 16, 16))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField_SearchTitleKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField_SearchTitleKeyReleased
        fillSubjectTable(jTextField_SearchTitle.getText());
    }//GEN-LAST:event_jTextField_SearchTitleKeyReleased

    private void jTextField_SearchTitleFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField_SearchTitleFocusGained
        jTextField_SearchTitle.setText("");
    }//GEN-LAST:event_jTextField_SearchTitleFocusGained

    private void jTextField_SearchTitleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextField_SearchTitleMouseClicked
        jTextField_SearchTitle.setText("");
        fillSubjectTable(jTextField_SearchTitle.getText());
    }//GEN-LAST:event_jTextField_SearchTitleMouseClicked

    private void jTable_SubjectMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable_SubjectMouseClicked
        getSelectedSubjectInfo();
        btnAddClassType.setEnabled(true);
        btnDelCType.setEnabled(true);
        btnAddPre.setEnabled(true);
        btnDelPre.setEnabled(true);
    }//GEN-LAST:event_jTable_SubjectMouseClicked

    private void jTable_SubjectKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable_SubjectKeyReleased
        getSelectedSubjectInfo();
    }//GEN-LAST:event_jTable_SubjectKeyReleased

    private void btnDelSubjActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelSubjActionPerformed

        if(jTable_Subject.getSelectedRowCount() == 1){
            int sID = subjectID.get(jTable_Subject.getSelectedRow());
            deleteSubject(sID);
        } else if (jTable_Subject.getSelectedRowCount() < 1){
            deleteSubject(0);
        }
        fillSubjectTable("");        
        getSelectedSubject(subjectID.get(0));
        getSelectedSubjectInfo();
        fillClassTypeTable(subjectID.get(0));
        btnAddClassType.setEnabled(false);
        fillPreSubjList(mysID);
        fillPrqstSubjCB();
    }//GEN-LAST:event_btnDelSubjActionPerformed

    private void btnAddSubjActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddSubjActionPerformed

        addSubject();
        fillSubjectTable("");
        getSelectedSubject(subjectID.get(0));
        fillClassTypeTable(subjectID.get(0));
        btnAddClassType.setEnabled(true);
        btnDelCType.setEnabled(true);
        btnAddPre.setEnabled(true);
        btnDelPre.setEnabled(true);
        mysID = subjectID.get(0);
        fillPreSubjList(mysID);
        fillPrqstSubjCB();
    }//GEN-LAST:event_btnAddSubjActionPerformed

    private void jTextField_SubjectCodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_SubjectCodeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField_SubjectCodeActionPerformed

    private void jTextField_SubjectTitleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_SubjectTitleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField_SubjectTitleActionPerformed

    private void btnSaveSubjActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveSubjActionPerformed
        if(jTable_Subject.getSelectedRowCount() != 1){
            saveSubject(subjectID.get(0));
            fillSubjectTable("");
            fillPreSubjList(mysID);
            fillPrqstSubjCB();
            fillPanel();
        } else {
            saveSubject(subjectID.get(jTable_Subject.getSelectedRow()));
            fillSubjectTable("");
            fillPreSubjList(mysID);
            fillPrqstSubjCB();
            fillPanel();
        } 
    }//GEN-LAST:event_btnSaveSubjActionPerformed

    private void btnAddClassTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddClassTypeActionPerformed
        // TODO add your handling code here:
        btnAddClassType.setVisible(false);
        panelContainer.setVisible(true);
    }//GEN-LAST:event_btnAddClassTypeActionPerformed

    private void cbClassTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbClassTypeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbClassTypeActionPerformed

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        // TODO add your handling code here:
        panelContainer.setVisible(false);
        btnAddClassType.setVisible(true);
    }//GEN-LAST:event_btnCancelActionPerformed

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
        ClassType(mysID);
        fillClassTypeTable(mysID);
        panelContainer.setVisible(false);
        btnAddClassType.setVisible(true);
    }//GEN-LAST:event_btnAddActionPerformed

    private void jTable_ClassTypeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable_ClassTypeMouseClicked
        // TODO add your handling code here:
        
        fillPanel();
        panelContainer.setVisible(true);
        btnAddClassType.setVisible(false);
    }//GEN-LAST:event_jTable_ClassTypeMouseClicked

    private void btnDelCTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelCTypeActionPerformed
        delClassType(mysID, jTable_ClassType.getValueAt(jTable_ClassType.getSelectedRow(), jTable_ClassType.getSelectedColumn()).toString());
        panelContainer.setVisible(false);
        btnAddClassType.setVisible(true);
    }//GEN-LAST:event_btnDelCTypeActionPerformed

    private void jTable_PreSubjMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable_PreSubjMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable_PreSubjMouseClicked

    private void jTable_PreSubjKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable_PreSubjKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable_PreSubjKeyReleased

    private void btnAddPreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddPreActionPerformed
        addPrerequisite();
        fillPreSubjList(mysID);
    }//GEN-LAST:event_btnAddPreActionPerformed

    private void btnDelPreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelPreActionPerformed
        delPrerequisite();
    }//GEN-LAST:event_btnDelPreActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SubjectUpdate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SubjectUpdate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SubjectUpdate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SubjectUpdate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SubjectUpdate().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnAddClassType;
    private javax.swing.JButton btnAddPre;
    private javax.swing.JButton btnAddSubj;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnDelCType;
    private javax.swing.JButton btnDelPre;
    private javax.swing.JButton btnDelSubj;
    private javax.swing.JButton btnSaveSubj;
    private javax.swing.JComboBox<String> cbClassType;
    private javax.swing.JComboBox<String> cbSubjects;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable jTable_ClassType;
    private javax.swing.JTable jTable_PreSubj;
    private javax.swing.JTable jTable_Subject;
    private javax.swing.JTextField jTextField_SearchTitle;
    private javax.swing.JTextField jTextField_SubjectCode;
    private javax.swing.JTextField jTextField_SubjectTitle;
    private javax.swing.JTextField jTextField_Units;
    private javax.swing.JLabel lblHours;
    private javax.swing.JLabel lblType;
    private javax.swing.JPanel panelContainer;
    private javax.swing.JPanel pnlCType;
    private javax.swing.JTextField txtHours;
    // End of variables declaration//GEN-END:variables
}
