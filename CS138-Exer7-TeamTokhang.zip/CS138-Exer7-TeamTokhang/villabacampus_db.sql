-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2018 at 08:42 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `villabacampus_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `courseID` int(11) NOT NULL,
  `courseCode` varchar(10) DEFAULT NULL,
  `courseTitle` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`courseID`, `courseCode`, `courseTitle`) VALUES
(1, 'BEED', 'Bachelor of Elementary Education'),
(2, 'BSA', 'Bachelor of Science in Agriculture'),
(3, 'BSED', 'Bachelor of Secondary Education');

-- --------------------------------------------------------

--
-- Table structure for table `curriculum`
--

CREATE TABLE `curriculum` (
  `majorID` int(11) NOT NULL,
  `subjectID` int(11) NOT NULL,
  `subjectType` varchar(10) NOT NULL,
  `yearlevel` int(5) NOT NULL,
  `term` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `curriculum`
--

INSERT INTO `curriculum` (`majorID`, `subjectID`, `subjectType`, `yearlevel`, `term`) VALUES
(1, 1, 'Lecture', 1, 'First'),
(1, 2, 'Lecture', 1, 'First'),
(1, 3, 'Lecture', 1, 'First'),
(1, 4, 'Laboratory', 1, 'First'),
(1, 4, 'Lecture', 1, 'First'),
(1, 5, 'Lecture', 1, 'First'),
(1, 6, 'Lecture', 1, 'First'),
(1, 7, 'Lecture', 1, 'First'),
(1, 8, 'Lecture', 1, 'First'),
(1, 9, 'Laboratory', 1, 'Second'),
(1, 9, 'Lecture', 1, 'Second'),
(1, 10, 'Lecture', 1, 'Second'),
(1, 11, 'Lecture', 1, 'Second'),
(1, 12, 'Lecture', 1, 'Second'),
(1, 13, 'Lecture', 1, 'Second'),
(1, 14, 'Lecture', 1, 'Second'),
(1, 15, 'Laboratory', 1, 'Second'),
(1, 15, 'Lecture', 1, 'Second'),
(1, 16, 'Lecture', 1, 'Second'),
(1, 17, 'Lecture', 1, 'Second');

-- --------------------------------------------------------

--
-- Table structure for table `majors`
--

CREATE TABLE `majors` (
  `majorID` int(11) NOT NULL,
  `courseID` int(11) DEFAULT NULL,
  `majorTitle` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `majors`
--

INSERT INTO `majors` (`majorID`, `courseID`, `majorTitle`) VALUES
(1, 1, 'General Education'),
(2, 2, 'Agronomy'),
(3, 2, 'Animal Science'),
(4, 3, 'Biological Sciences'),
(5, 3, 'English'),
(6, 3, 'Mathematics');

-- --------------------------------------------------------

--
-- Table structure for table `prerequisite`
--

CREATE TABLE `prerequisite` (
  `subjectID` int(11) NOT NULL,
  `preSubjectID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prerequisite`
--

INSERT INTO `prerequisite` (`subjectID`, `preSubjectID`) VALUES
(10, 1),
(12, 2),
(13, 5),
(14, 6),
(16, 7),
(17, 8);

-- --------------------------------------------------------

--
-- Table structure for table `subjectdetails`
--

CREATE TABLE `subjectdetails` (
  `subjectID` int(11) NOT NULL,
  `subjectType` varchar(10) NOT NULL,
  `hours` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjectdetails`
--

INSERT INTO `subjectdetails` (`subjectID`, `subjectType`, `hours`) VALUES
(1, 'Lecture', 4),
(2, 'Lecture', 3),
(3, 'Lecture', 3),
(4, 'Laboratory', 6),
(4, 'Lecture', 3),
(5, 'Lecture', 3),
(6, 'Lecture', 3),
(7, 'Lecture', 2),
(8, 'Lecture', 3),
(9, 'Laboratory', 3),
(9, 'Lecture', 3),
(10, 'Lecture', 4),
(11, 'Lecture', 3),
(12, 'Lecture', 3),
(13, 'Lecture', 3),
(14, 'Lecture', 3),
(15, 'Laboratory', 3),
(15, 'Lecture', 2),
(16, 'Lecture', 2),
(17, 'Lecture', 3);

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `subjectID` int(11) NOT NULL,
  `subjectCode` varchar(10) DEFAULT NULL,
  `subjectTitle` varchar(50) DEFAULT NULL,
  `units` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`subjectID`, `subjectCode`, `subjectTitle`, `units`) VALUES
(1, 'Math 10a', 'Fundamentals of Mathematics', 4),
(2, 'Psyc 11', 'General Psychology', 3),
(3, 'Econ 11', 'General Economics with Taxation and Agrarian Refor', 3),
(4, 'Chem 15', 'General Inorganic Chemistry I', 5),
(5, 'Engl 11', 'Study and Thinking Skills', 3),
(6, 'Fili 11', 'Komunikasyon sa Akademikong Filipino', 3),
(7, 'PhEd 11', 'Physical Fitness and Gymnastics', 2),
(8, 'NSTP 11', 'National Service Training Program', 3),
(9, 'Biol 11', 'General Biology', 4),
(10, 'Math 10b', 'Contemporary Mathematics', 4),
(11, 'Soci 11', 'Society and Culture with Family Planning', 3),
(12, 'PrEd 123', 'Child and Adolescent Development', 3),
(13, 'Engl 12', 'Writing in the Discipline', 3),
(14, 'Fili 12', 'Pagbasa at Pagsulat Tungo sa Pananaliksik', 3),
(15, 'CSci 21', 'Information and Communication Technology: Concepts', 3),
(16, 'PhEd 12', 'Recr’l. Games, Rhythmic Act. And Dance', 2),
(17, 'NSTP 12', 'National Service Training Program', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`courseID`);

--
-- Indexes for table `curriculum`
--
ALTER TABLE `curriculum`
  ADD PRIMARY KEY (`majorID`,`subjectID`,`subjectType`,`yearlevel`,`term`);

--
-- Indexes for table `majors`
--
ALTER TABLE `majors`
  ADD PRIMARY KEY (`majorID`),
  ADD KEY `courseID` (`courseID`);

--
-- Indexes for table `prerequisite`
--
ALTER TABLE `prerequisite`
  ADD PRIMARY KEY (`subjectID`,`preSubjectID`),
  ADD KEY `preSubjectID` (`preSubjectID`);

--
-- Indexes for table `subjectdetails`
--
ALTER TABLE `subjectdetails`
  ADD PRIMARY KEY (`subjectID`,`subjectType`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`subjectID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `courseID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `majors`
--
ALTER TABLE `majors`
  MODIFY `majorID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `subjectID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `majors`
--
ALTER TABLE `majors`
  ADD CONSTRAINT `majors_ibfk_1` FOREIGN KEY (`courseID`) REFERENCES `courses` (`courseID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
