/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FrontEnd;

import Connection.myConnect;
import java.awt.Dimension;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Keen
 */
public class CurriculumInternalFrame extends javax.swing.JInternalFrame {

    private Connection myCon;
    private ArrayList<Integer> majorID;
    private ArrayList<Integer> courseID;
    private ArrayList<String> courseAndMajor;
    private int [] yearAndLevelArr = new int [] {1,2,3,4};
    private String [] semesterArr = new String [] {"First", "Second", "Summer"};
    private String username;
    private String password;
    private String hostName;
    private String databaseName;
    boolean listenedToWindow = false;
    
    /**
     * Creates new form CurriculumInternalFrame
     */
    public CurriculumInternalFrame(String uname, String pword, String lhost, String dbase) {
        initComponents();
        setResizable(false);
        
        // Establish Connection
        setServerInformation(uname, pword, lhost, dbase);
        setServer();
        
        setCourseAndMajorData(0,0,0);
    }
    
    public void setServerInformation(String username, String password, String hostName, String databaseName){
        
        this.username = username;
        this.password = password;
        this.hostName = hostName;
        this.databaseName = databaseName;
        
    }
    
    public void setServer(){
        myCon = myConnect.ConnectDB(username, password, hostName, databaseName);
    }
    
    public void setCourseAndMajorData(int cmIndex, int yAndLIndex, int semIndex){
        
        majorID = new ArrayList<>();
        courseID = new ArrayList<>();
        courseAndMajor = new ArrayList<>();
        
        
        String query = "SELECT m.majorID, m.majorTitle,c.courseID, c.courseCode, c.courseTitle FROM majors AS m "
                + "INNER JOIN courses AS c ON m.courseID = c.courseID ORDER BY c.courseCode ASC, m.majorTitle ASC ";
         
        try {
            PreparedStatement myStat = myCon.prepareStatement(query);
            ResultSet rs = myStat.executeQuery();
            
            while(rs.next()){
                majorID.add(rs.getInt("m.majorID"));
                courseID.add(rs.getInt("c.courseID"));
                String courseAndMajorString = rs.getString("c.courseTitle") + " | " + rs.getString("m.majorTitle");
                courseAndMajor.add(courseAndMajorString);
            } 
            jComboBox_CourseAndMajor.setModel(new DefaultComboBoxModel(courseAndMajor.toArray()));
            
            jComboBox_CourseAndMajor.setSelectedIndex(cmIndex);
            jComboBox_YearAndLevel.setSelectedIndex(yAndLIndex);
            jComboBox_Semester.setSelectedIndex(semIndex);
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error: " + e, "Error", JOptionPane.ERROR_MESSAGE);
        }         
    }
    
    public void fillOfferedSubjectTable(int majorID, int courseID, int yearLevel, String term){

        String query = "SELECT s.subjectCode, s.subjectTitle, sd.subjectType, sd.hours FROM subjects AS s "
                + "INNER JOIN subjectdetails as sd ON s.subjectID = sd.subjectID INNER JOIN curriculum AS c "
                + "ON sd.subjectID = c.subjectID AND sd.subjectType = c.subjectType INNER JOIN majors AS m "
                + "ON c.majorID=m.majorID WHERE c.majorID = ? and m.courseID = ? and yearLevel = ? and term = ?"
                + "ORDER BY s.subjectCode ASC, s.subjectTitle ASC";
        
         try {
            PreparedStatement myStat = myCon.prepareStatement(query);
            myStat.setInt(1, majorID);
            myStat.setInt(2, courseID);
            myStat.setInt(3, yearLevel);
            myStat.setString(4, term);
            ResultSet rs = myStat.executeQuery();
            
            DefaultTableModel model = (DefaultTableModel) jTable_OfferedSubjects.getModel();
            model.setRowCount(0);
            
            while(rs.next())
            { 
                String subjectCode = rs.getString("s.subjectCode");
                String subjectTitle = rs.getString("s.subjectTitle");
                String subjectType = rs.getString("sd.subjectType");
                int hours = rs.getInt("hours");
                
                model.insertRow(jTable_OfferedSubjects.getRowCount(), new Object[] {subjectCode, subjectTitle, subjectType, hours});
            }
            
            // Center Alignment for hour(column)
            DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
            centerRenderer.setHorizontalAlignment(javax.swing.JLabel.CENTER);
            jTable_OfferedSubjects.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
            
        } catch (Exception e){
            System.out.println("Error : " + e);
        }

    }
    
    public void fillAvailableSubjectTable(int majorID, int courseID, int yearLevel, String term, String subCodeSearch, String subTitleSearch){
        
        String query = "SELECT subj.subjectCode, subj.subjectTitle, subj.subjectType, subj.hours FROM "
                + "(SELECT s.subjectCode, s.subjectTitle, sd.subjectType, sd.hours FROM subjects AS s "
                + "INNER JOIN subjectdetails AS sd ON s.subjectID=sd.subjectID) as subj "
                + "LEFT JOIN (SELECT s.subjectCode, s.subjectTitle, sd.subjectType, sd.hours FROM subjects AS s "
                + "LEFT JOIN subjectdetails as sd ON s.subjectID = sd.subjectID LEFT JOIN curriculum AS c "
                + "ON sd.subjectID = c.subjectID AND sd.subjectType = c.subjectType LEFT JOIN majors AS m "
                + "ON c.majorID=m.majorID WHERE c.majorID = ? AND m.courseID = ? AND yearLevel = ? AND "
                + "term = ?) as curr ON subj.subjectCode = curr.subjectCode WHERE curr.subjectCode IS NULL "
                + "AND (subj.subjectCode LIKE ? OR subj.subjectTitle LIKE ?)"
                + "ORDER BY subj.subjectCode ASC, subj.subjectTitle ASC";
        
         try {
            PreparedStatement myStat = myCon.prepareStatement(query);
            myStat.setInt(1, majorID);
            myStat.setInt(2, courseID);
            myStat.setInt(3, yearLevel);
            myStat.setString(4, term);
            myStat.setString(5, subCodeSearch + "%");
            myStat.setString(6, subTitleSearch + "%");
            ResultSet rs = myStat.executeQuery();
            
            DefaultTableModel model = (DefaultTableModel) jTable_AvailableSubjects.getModel();
            model.setRowCount(0);
            
            while(rs.next())
            { 
                String subjectCode = rs.getString("subj.subjectCode");
                String subjectTitle = rs.getString("subj.subjectTitle");
                String subjectType = rs.getString("subj.subjectType");
                int hours = rs.getInt("subj.hours");
                
                model.insertRow(jTable_AvailableSubjects.getRowCount(), new Object[] {subjectCode, subjectTitle, subjectType, hours});
            }
            
            //Center Alignment for hour(column)
            DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
            centerRenderer.setHorizontalAlignment(javax.swing.JLabel.CENTER);
            jTable_AvailableSubjects.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
            
        } catch (Exception e){
            System.out.println("Error : " + e);
        }
        
    }
    
    public int getSelectedSubjectID(String subjCode){    
        int subjectID = 0;
        String query = "SELECT subjectID FROM subjects WHERE subjectCode = ?";
        
        try{
            PreparedStatement myStat = myCon.prepareStatement(query);
            myStat.setString(1, subjCode);
            ResultSet rs = myStat.executeQuery();
            
            if(rs.next()){
               subjectID = rs.getInt("subjectID");
            }
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error: " + e, "Error", JOptionPane.ERROR_MESSAGE);
        }  
        return subjectID;
    }
    
    public void removeSelectedSubjects(int rowIndex){
        String selectedSubjectCode = String.valueOf(jTable_OfferedSubjects.getValueAt(rowIndex, 0));
        
        int majID = majorID.get(jComboBox_CourseAndMajor.getSelectedIndex());
        int selectedID = getSelectedSubjectID(selectedSubjectCode);
        String selectedType = String.valueOf(jTable_OfferedSubjects.getValueAt(rowIndex, 2));
        int year = yearAndLevelArr[jComboBox_YearAndLevel.getSelectedIndex()];
        String term = semesterArr[jComboBox_Semester.getSelectedIndex()];

        String query = "DELETE FROM curriculum WHERE majorID = ? and subjectID = ? and subjectType = ? and yearLevel = ? and Term = ?";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(query);

            myStat.setInt(1, majID); 
            myStat.setInt(2, selectedID); 
            myStat.setString(3, selectedType);
            myStat.setInt(4, year); 
            myStat.setString(5, term);
            myStat.executeUpdate();
           
            
        } catch (Exception e){
            System.out.println("Error : " + e);
        }
    }
    
    public void addSelectedSubjects(int rowIndex){
        String selectedSubjectCode = String.valueOf(jTable_AvailableSubjects.getValueAt(rowIndex, 0));
        
        int majID = majorID.get(jComboBox_CourseAndMajor.getSelectedIndex());
        int selectedID = getSelectedSubjectID(selectedSubjectCode);
        String selectedType = String.valueOf(jTable_AvailableSubjects.getValueAt(rowIndex, 2));
        int year = yearAndLevelArr[jComboBox_YearAndLevel.getSelectedIndex()];
        String term = semesterArr[jComboBox_Semester.getSelectedIndex()];

        String query = "INSERT INTO curriculum(majorID, subjectID, subjectType, yearlevel, term)"
                + " VALUES (?,?,?,?,?)";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(query);

            myStat.setInt(1, majID); 
            myStat.setInt(2, selectedID); 
            myStat.setString(3, selectedType);
            myStat.setInt(4, year); 
            myStat.setString(5, term);
            
            myStat.executeUpdate();
           
            
        } catch (Exception e){
            System.out.println("Error : " + e);
            JOptionPane.showMessageDialog(null,"Subject Already Added...","Error",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void updateTables(){
        int majID = majorID.get(jComboBox_CourseAndMajor.getSelectedIndex());
        int cID = courseID.get(jComboBox_CourseAndMajor.getSelectedIndex());
        int year = yearAndLevelArr[jComboBox_YearAndLevel.getSelectedIndex()];
        String term = semesterArr[jComboBox_Semester.getSelectedIndex()];
        fillOfferedSubjectTable(majID, cID, year, term);
        fillAvailableSubjectTable(majID, cID, year, term, "", "");
    }
    
    public void searchSubject(){
        int majID = majorID.get(jComboBox_CourseAndMajor.getSelectedIndex());
        int cID = courseID.get(jComboBox_CourseAndMajor.getSelectedIndex());
        int year = yearAndLevelArr[jComboBox_YearAndLevel.getSelectedIndex()];
        String term = semesterArr[jComboBox_Semester.getSelectedIndex()];
        String search = jTextField_SearchField.getText();
        fillAvailableSubjectTable(majID, cID, year, term, search, search);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel_MajorAndDegree = new javax.swing.JLabel();
        jLabel_YearAndLevel = new javax.swing.JLabel();
        jLabel_Semester = new javax.swing.JLabel();
        jComboBox_CourseAndMajor = new javax.swing.JComboBox<>();
        jComboBox_YearAndLevel = new javax.swing.JComboBox<>();
        jComboBox_Semester = new javax.swing.JComboBox<>();
        jButton_Manage = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_OfferedSubjects = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable_AvailableSubjects = new javax.swing.JTable();
        jButton_AddSubject = new javax.swing.JButton();
        jButton_RemoveSubject = new javax.swing.JButton();
        jLabel_OfferedSubjects = new javax.swing.JLabel();
        jLabel_OfferedSubjects1 = new javax.swing.JLabel();
        jTextField_SearchField = new javax.swing.JTextField();

        setClosable(true);
        setIconifiable(true);
        setTitle("Curriculum");
        setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/vsu.jpg"))); // NOI18N

        jPanel1.setBackground(java.awt.Color.WHITE);

        jPanel2.setBackground(java.awt.Color.WHITE);
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel_MajorAndDegree.setBackground(new java.awt.Color(255, 255, 255));
        jLabel_MajorAndDegree.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        jLabel_MajorAndDegree.setText("Course and Major");

        jLabel_YearAndLevel.setBackground(new java.awt.Color(255, 255, 255));
        jLabel_YearAndLevel.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        jLabel_YearAndLevel.setText("Year and Level");

        jLabel_Semester.setBackground(new java.awt.Color(255, 255, 255));
        jLabel_Semester.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        jLabel_Semester.setText("Semester");

        jComboBox_CourseAndMajor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_CourseAndMajorActionPerformed(evt);
            }
        });

        jComboBox_YearAndLevel.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "First Year", "Second Year", "Third Year", "Fourth Year" }));
        jComboBox_YearAndLevel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_YearAndLevelActionPerformed(evt);
            }
        });

        jComboBox_Semester.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "First Semester", "Second Semester", "Summer" }));
        jComboBox_Semester.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_SemesterActionPerformed(evt);
            }
        });

        jButton_Manage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/update.png"))); // NOI18N
        jButton_Manage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_ManageActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel_YearAndLevel)
                            .addComponent(jLabel_Semester))
                        .addGap(35, 35, 35)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jComboBox_YearAndLevel, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox_Semester, 0, 356, Short.MAX_VALUE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel_MajorAndDegree)
                        .addGap(18, 18, 18)
                        .addComponent(jComboBox_CourseAndMajor, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton_Manage)
                .addContainerGap(12, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel_MajorAndDegree)
                            .addComponent(jComboBox_CourseAndMajor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel_YearAndLevel)
                            .addComponent(jComboBox_YearAndLevel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jButton_Manage))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBox_Semester, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel_Semester))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTable_OfferedSubjects.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Subject Code", "Description", "Class Type", "# Hours"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable_OfferedSubjects.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(jTable_OfferedSubjects);
        if (jTable_OfferedSubjects.getColumnModel().getColumnCount() > 0) {
            jTable_OfferedSubjects.getColumnModel().getColumn(0).setResizable(false);
            jTable_OfferedSubjects.getColumnModel().getColumn(0).setPreferredWidth(120);
            jTable_OfferedSubjects.getColumnModel().getColumn(1).setResizable(false);
            jTable_OfferedSubjects.getColumnModel().getColumn(1).setPreferredWidth(400);
            jTable_OfferedSubjects.getColumnModel().getColumn(2).setResizable(false);
            jTable_OfferedSubjects.getColumnModel().getColumn(2).setPreferredWidth(150);
            jTable_OfferedSubjects.getColumnModel().getColumn(3).setResizable(false);
            jTable_OfferedSubjects.getColumnModel().getColumn(3).setPreferredWidth(100);
        }

        jTable_AvailableSubjects.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Subject Code", "Description", "Class Type", "# Hours"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable_AvailableSubjects.getTableHeader().setReorderingAllowed(false);
        jScrollPane2.setViewportView(jTable_AvailableSubjects);
        if (jTable_AvailableSubjects.getColumnModel().getColumnCount() > 0) {
            jTable_AvailableSubjects.getColumnModel().getColumn(0).setResizable(false);
            jTable_AvailableSubjects.getColumnModel().getColumn(0).setPreferredWidth(120);
            jTable_AvailableSubjects.getColumnModel().getColumn(1).setResizable(false);
            jTable_AvailableSubjects.getColumnModel().getColumn(1).setPreferredWidth(400);
            jTable_AvailableSubjects.getColumnModel().getColumn(2).setResizable(false);
            jTable_AvailableSubjects.getColumnModel().getColumn(2).setPreferredWidth(150);
            jTable_AvailableSubjects.getColumnModel().getColumn(3).setResizable(false);
            jTable_AvailableSubjects.getColumnModel().getColumn(3).setPreferredWidth(100);
        }

        jButton_AddSubject.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/leftArrow.png"))); // NOI18N
        jButton_AddSubject.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_AddSubjectActionPerformed(evt);
            }
        });

        jButton_RemoveSubject.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/rightArrow.png"))); // NOI18N
        jButton_RemoveSubject.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_RemoveSubjectActionPerformed(evt);
            }
        });

        jLabel_OfferedSubjects.setBackground(new java.awt.Color(255, 255, 255));
        jLabel_OfferedSubjects.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        jLabel_OfferedSubjects.setText("Offered Subjects");

        jLabel_OfferedSubjects1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel_OfferedSubjects1.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        jLabel_OfferedSubjects1.setText("Available Subjects");

        jTextField_SearchField.setText("Search Subject Here");
        jTextField_SearchField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextField_SearchFieldFocusGained(evt);
            }
        });
        jTextField_SearchField.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTextField_SearchFieldMouseClicked(evt);
            }
        });
        jTextField_SearchField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField_SearchFieldKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(213, 213, 213)
                        .addComponent(jLabel_OfferedSubjects)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel_OfferedSubjects1)
                        .addGap(76, 76, 76)
                        .addComponent(jTextField_SearchField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 533, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jButton_AddSubject, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton_RemoveSubject, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 533, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel_OfferedSubjects)
                    .addComponent(jLabel_OfferedSubjects1)
                    .addComponent(jTextField_SearchField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(126, 126, 126)
                        .addComponent(jButton_AddSubject)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton_RemoveSubject)
                        .addGap(108, 108, 108)))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox_CourseAndMajorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_CourseAndMajorActionPerformed
        updateTables();
    }//GEN-LAST:event_jComboBox_CourseAndMajorActionPerformed

    private void jComboBox_YearAndLevelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_YearAndLevelActionPerformed
        updateTables();
    }//GEN-LAST:event_jComboBox_YearAndLevelActionPerformed

    private void jComboBox_SemesterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_SemesterActionPerformed
        updateTables();
    }//GEN-LAST:event_jComboBox_SemesterActionPerformed

    private void jButton_ManageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_ManageActionPerformed
        int cID = courseID.get(jComboBox_CourseAndMajor.getSelectedIndex());
        DegreeProgramForm DProgramForm = new DegreeProgramForm(username,password,hostName,databaseName,cID);

        //Makes DegreeProgramForm as modal dialog
        JDialog dialog = new JDialog(DProgramForm);
        dialog.setTitle(DProgramForm.getTitle());
        dialog.setSize(new Dimension(DProgramForm.getWidth(), DProgramForm.getHeight()));
        dialog.setLocationRelativeTo(DProgramForm);
        dialog.add(DProgramForm.getContentPane());
        dialog.setModal(true);
        dialog.setVisible(true);

        //setCourseAndMajorData(jComboBox_CourseAndMajor.getSelectedIndex(),jComboBox_YearAndLevel.getSelectedIndex(),jComboBox_Semester.getSelectedIndex());
        setCourseAndMajorData(0,0,0);
    }//GEN-LAST:event_jButton_ManageActionPerformed

    private void jButton_AddSubjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_AddSubjectActionPerformed
        int [] numOfSelectedRowsArr = jTable_AvailableSubjects.getSelectedRows();

        if(numOfSelectedRowsArr.length>0){
            for(int i=0; i<numOfSelectedRowsArr.length;i++){
                addSelectedSubjects(numOfSelectedRowsArr[i]);
            }

            updateTables();
            jTextField_SearchField.setText("Search Subject Here");
        } else {
            JOptionPane.showMessageDialog(null, "No Subject(s) Selected...","Warning!",JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_jButton_AddSubjectActionPerformed

    private void jButton_RemoveSubjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_RemoveSubjectActionPerformed
        int [] numOfSelectedRowsArr = jTable_OfferedSubjects.getSelectedRows();

        if(numOfSelectedRowsArr.length>0){

            for(int i=0; i<numOfSelectedRowsArr.length;i++){
                removeSelectedSubjects(numOfSelectedRowsArr[i]);
            }

            updateTables();
        } else {
            JOptionPane.showMessageDialog(null, "No Subject(s) Selected...","Warning!",JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_jButton_RemoveSubjectActionPerformed

    private void jTextField_SearchFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField_SearchFieldFocusGained
        jTextField_SearchField.setText("");
    }//GEN-LAST:event_jTextField_SearchFieldFocusGained

    private void jTextField_SearchFieldMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextField_SearchFieldMouseClicked
        jTextField_SearchField.setText("");
        searchSubject();
    }//GEN-LAST:event_jTextField_SearchFieldMouseClicked

    private void jTextField_SearchFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField_SearchFieldKeyReleased
        searchSubject();
    }//GEN-LAST:event_jTextField_SearchFieldKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_AddSubject;
    private javax.swing.JButton jButton_Manage;
    private javax.swing.JButton jButton_RemoveSubject;
    private javax.swing.JComboBox<String> jComboBox_CourseAndMajor;
    private javax.swing.JComboBox<String> jComboBox_Semester;
    private javax.swing.JComboBox<String> jComboBox_YearAndLevel;
    private javax.swing.JLabel jLabel_MajorAndDegree;
    private javax.swing.JLabel jLabel_OfferedSubjects;
    private javax.swing.JLabel jLabel_OfferedSubjects1;
    private javax.swing.JLabel jLabel_Semester;
    private javax.swing.JLabel jLabel_YearAndLevel;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable_AvailableSubjects;
    private javax.swing.JTable jTable_OfferedSubjects;
    private javax.swing.JTextField jTextField_SearchField;
    // End of variables declaration//GEN-END:variables
}
