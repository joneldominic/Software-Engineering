/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package FrontEnd;

import Connection.myConnect;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Keen
 */
public class DegreeProgramForm extends javax.swing.JFrame {

    private Connection myCon;
    private String username;
    private String password;
    private String hostName;
    private String databaseName;
    private ArrayList<Integer> courseID;
    private ArrayList<Integer> majorID;
    private int selectedMajorID;//----------------------------------------------
    
    /** Creates new form DegreeProgram */
    public DegreeProgramForm() {
        initComponents();
        setLocationRelativeTo(this);
        setResizable(false);
    }
    
    public DegreeProgramForm(String username, String password, String hostName, String databaseName, int selectCourseID){
        initComponents();
        setLocationRelativeTo(this);
        setResizable(false);
        setIcon();
        
        this.username = username;
        this.password = password;
        this.hostName = hostName;
        this.databaseName = databaseName;
        myCon = myConnect.ConnectDB(username, password, hostName, databaseName);
        
        setDegreeData();
        setSelectedCourse(selectCourseID);
        
    }
    
    private void setIcon() {
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("../Images/vsu.jpg")));
    }
    
    public void setDegreeData(){
        
        courseID = new ArrayList<>();
        
        String query = "SELECT courseID, courseCode, courseTitle FROM courses ORDER BY courseCode ASC, courseTitle ASC";
        
        try{
            PreparedStatement myStat = myCon.prepareStatement(query);
            ResultSet rs = myStat.executeQuery();
            
            while(rs.next()){
                courseID.add(rs.getInt("courseID"));
                String degree = rs.getString("courseCode") + " | " + rs.getString("courseTitle") ;
                jComboBox_DegreeProgram.addItem(degree);
            }
            
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error: " + e, "Error", JOptionPane.ERROR_MESSAGE);
        } 
    }
    
    public void setSelectedCourse(int selectCourseID){
        for(int i=0; i<courseID.size();i++){
            if(courseID.get(i) == selectCourseID){
                jComboBox_DegreeProgram.setSelectedIndex(i);
            }
        }
    }
    
    public void setMajorsTable(int courseID){
        
        majorID  = new ArrayList<>();
        
        String query = "SELECT majorID, majorTitle FROM majors WHERE courseID = ? ORDER BY majorTitle ASC";
        
        try{
            PreparedStatement myStat = myCon.prepareStatement(query);
            myStat.setInt(1, courseID);
            ResultSet rs = myStat.executeQuery();
            
            DefaultTableModel model = (DefaultTableModel) jTable_Majors.getModel();
            model.setRowCount(0);
            
            while(rs.next())
            { 
                String majorTitle = rs.getString("majorTitle");
                majorID.add(rs.getInt("majorID"));
                model.insertRow(jTable_Majors.getRowCount(), new Object[] {majorTitle});
            }
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error: " + e, "Error", JOptionPane.ERROR_MESSAGE);
        }  
    }
  
    public void selectedMajorChanged(){
        if(jTable_Majors.getSelectedRowCount() == 1){
            jTextField_SelectedMajor.setText((String) jTable_Majors.getValueAt(jTable_Majors.getSelectedRow() , 0));
        }
    }
    
    public void saveMajor(int selectedMajorID){
        String newMajorTitle = jTextField_SelectedMajor.getText();
                
        String query = "UPDATE majors SET majorTitle = ?  WHERE majorID = ?";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(query);
            myStat.setString(1, newMajorTitle);
            myStat.setInt(2, selectedMajorID);
            
            myStat.executeUpdate();
            
        } catch (Exception e){
            JOptionPane.showMessageDialog (null, "Update Failed!", "Error", JOptionPane.ERROR_MESSAGE);
            System.out.println("Error : " + e);
        }
    }
    
    public void addMajor(int currentCourseID){
         
        String query = "INSERT INTO majors(courseID, majorTitle) VALUES (?, \"New Major Here <------\")";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(query);
            myStat.setInt(1, currentCourseID);
            
            myStat.executeUpdate();
            
        } catch (Exception e){
            JOptionPane.showMessageDialog (null, "Failed to Add Major", "Error", JOptionPane.ERROR_MESSAGE);
            System.out.println("Error : " + e);
        }
    }
    
    public void deleteMajor(int courseID, int majorID ){
        
        String query = "DELETE FROM majors WHERE courseID = ? AND majorID = ? ";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(query);
            myStat.setInt(1, courseID);
            myStat.setInt(2, majorID);
            
            myStat.executeUpdate();
            
        } catch (Exception e){
            JOptionPane.showMessageDialog (null, "Failed to Delete Major", "Error", JOptionPane.ERROR_MESSAGE);
            System.out.println("Error : " + e);
        }
    }
   
    
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jComboBox_DegreeProgram = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_Majors = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jTextField_SelectedMajor = new javax.swing.JTextField();
        jButton_AddMajor = new javax.swing.JButton();
        jButton_Save = new javax.swing.JButton();
        jButton_Delete = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Degree Program");

        jPanel1.setBackground(java.awt.Color.WHITE);

        jLabel1.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        jLabel1.setText("Degree Program");

        jComboBox_DegreeProgram.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_DegreeProgramActionPerformed(evt);
            }
        });

        jTable_Majors.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Major(s)"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable_Majors.getTableHeader().setReorderingAllowed(false);
        jTable_Majors.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_MajorsMouseClicked(evt);
            }
        });
        jTable_Majors.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTable_MajorsKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jTable_Majors);
        if (jTable_Majors.getColumnModel().getColumnCount() > 0) {
            jTable_Majors.getColumnModel().getColumn(0).setResizable(false);
        }

        jPanel2.setBackground(java.awt.Color.WHITE);
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel2.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        jLabel2.setText("Selected Major");

        jButton_AddMajor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/add.png"))); // NOI18N
        jButton_AddMajor.setText("Add Major");
        jButton_AddMajor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_AddMajorActionPerformed(evt);
            }
        });

        jButton_Save.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/save.png"))); // NOI18N
        jButton_Save.setText("Save");
        jButton_Save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_SaveActionPerformed(evt);
            }
        });

        jButton_Delete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/delete.png"))); // NOI18N
        jButton_Delete.setText("Delete");
        jButton_Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_DeleteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton_AddMajor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField_SelectedMajor))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jButton_Save, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton_Delete, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTextField_SelectedMajor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton_AddMajor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton_Save, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton_Delete, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox_DegreeProgram, javax.swing.GroupLayout.PREFERRED_SIZE, 302, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(31, 31, 31))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jComboBox_DegreeProgram))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox_DegreeProgramActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_DegreeProgramActionPerformed
        jTextField_SelectedMajor.setText("");
        setMajorsTable(courseID.get(jComboBox_DegreeProgram.getSelectedIndex()));
    }//GEN-LAST:event_jComboBox_DegreeProgramActionPerformed

    private void jButton_DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_DeleteActionPerformed
        if(jTable_Majors.getSelectedRowCount() == 1){
            
            if (JOptionPane.showConfirmDialog(null, "Delete Selected Major?", "Warning!",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                
                int cID = courseID.get(jComboBox_DegreeProgram.getSelectedIndex());
                int mID = majorID.get(jTable_Majors.getSelectedRow());
                deleteMajor(cID, mID);
                setMajorsTable(cID);
                jTextField_SelectedMajor.setText("");
            
            }
           
        } else {
            JOptionPane.showMessageDialog(null,"No Major Selected...", "Warning", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_jButton_DeleteActionPerformed

    private void jTable_MajorsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable_MajorsMouseClicked
        selectedMajorChanged();
    }//GEN-LAST:event_jTable_MajorsMouseClicked

    private void jTable_MajorsKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable_MajorsKeyReleased
        selectedMajorChanged();
    }//GEN-LAST:event_jTable_MajorsKeyReleased

    private void jButton_SaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_SaveActionPerformed
        if(jTable_Majors.getSelectedRowCount() == 1){
            saveMajor(majorID.get(jTable_Majors.getSelectedRow()));
            setMajorsTable(courseID.get(jComboBox_DegreeProgram.getSelectedIndex()));
            jTextField_SelectedMajor.setText("");
        } else {
            JOptionPane.showMessageDialog(null,"No Major Selected...", "Warning", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_jButton_SaveActionPerformed

    private void jButton_AddMajorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_AddMajorActionPerformed
        int currentCourseID = courseID.get(jComboBox_DegreeProgram.getSelectedIndex());
        addMajor(currentCourseID);
        setMajorsTable(currentCourseID);
    }//GEN-LAST:event_jButton_AddMajorActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DegreeProgramForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DegreeProgramForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DegreeProgramForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DegreeProgramForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DegreeProgramForm("root","","localhost","villabacampus_db", 0).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_AddMajor;
    private javax.swing.JButton jButton_Delete;
    private javax.swing.JButton jButton_Save;
    private javax.swing.JComboBox<String> jComboBox_DegreeProgram;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable_Majors;
    private javax.swing.JTextField jTextField_SelectedMajor;
    // End of variables declaration//GEN-END:variables

}
